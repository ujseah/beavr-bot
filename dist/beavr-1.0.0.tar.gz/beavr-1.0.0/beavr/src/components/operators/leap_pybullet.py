from copy import deepcopy as copy
from beavr.src.utils.network import ZMQKeypointSubscriber, ZMQKeypointPublisher
from .operator import Operator
from beavr.src.utils.timer import FrequencyTimer
from beavr.src.constants import *
import time
from concurrent.futures import ThreadPoolExecutor
import threading
import numpy as np
from beavr.src.utils.logger import HandLogger
from .utils.leap_solver import LeapHandIKSolver
import queue

class LeapHandOperator(Operator):
    def __init__(self, host, transformed_keypoints_port, joint_angle_subscribe_port, joint_angle_publish_port, reset_publish_port, finger_configs, logging_config=None):
        self.notify_component_start('leap hand operator with PyBullet IK')
        self._host, self._port = host, transformed_keypoints_port
        
        # Subscriber for the transformed hand keypoints
        self._transformed_hand_keypoint_subscriber = ZMQKeypointSubscriber(
            host = self._host,
            port = self._port,
            topic = 'transformed_hand_coords'
        )
        # Subscriber for the transformed arm frame
        self._transformed_arm_keypoint_subscriber = ZMQKeypointSubscriber(
            host = self._host,
            port = self._port,
            topic = 'transformed_hand_frame'
        )
        # New publishers for joint control
        self._joint_angle_publisher = ZMQKeypointPublisher(
            host = host,
            port = joint_angle_publish_port
        )
        
        self._reset_publisher = ZMQKeypointPublisher(
            host = host,
            port = reset_publish_port
        )

        self._joint_angle_subscriber = ZMQKeypointSubscriber(
            host = host,
            port = joint_angle_subscribe_port,
            topic = 'joint_angles'
        )   

        # Initializing the finger configs
        self.finger_configs = finger_configs

        # Initialize the PyBullet IK solver
        self.ik_solver = LeapHandIKSolver(use_gui=False)

        # Initialzing the moving average queues (kept for compatibility)
        self.moving_average_queues = {
            'thumb': [],
            'index': [],
            'middle': [],
            'ring': []
        }

        self._robot = None
        self._timer = FrequencyTimer(VR_FREQ)

        # Initialize FPS counter and start time
        self._frame_count = 0
        self._start_time = time.time()
        self._last_angles = None

        # Create thread pool for parallel processing if needed
        self.thread_pool = ThreadPoolExecutor(max_workers=1)  # Single thread as PyBullet handles all fingers at once
        
        # Initialize logging with background thread
        self.logging_config = logging_config or {"enabled": False}
        self.logging_enabled = self.logging_config.get("enabled", False)
        
        if self.logging_enabled:
            print("Initializing hand logger with config:", self.logging_config)
            self.hand_logger = HandLogger(prefix="leap_hand_pybullet")
            
            # Create a queue for logging data
            self.log_queue = queue.Queue(maxsize=100)  # Limit queue size to prevent memory issues
            
            # Start background logging thread
            self._logging_thread_active = True
            self._logging_thread = threading.Thread(target=self._background_logging, daemon=True)
            self._logging_thread.start()
        else:
            self.hand_logger = None
            self.log_queue = None
            self._logging_thread = None

    @property
    def timer(self):
        return self._timer

    @property
    def transformed_arm_keypoint_subscriber(self):
        return self._transformed_arm_keypoint_subscriber
    
    @property
    def robot(self):
        return self._robot
    
    @property
    def transformed_hand_keypoint_subscriber(self):
        return self._transformed_hand_keypoint_subscriber
    
    # This function differentiates between the real robot and simulation
    def return_real(self):
        return False
    
    # Get the transformed finger coordinates
    def _get_finger_coords(self):
        raw_keypoints = self.transformed_hand_keypoint_subscriber.recv_keypoints()
        return dict(
            index = np.vstack([raw_keypoints[0], raw_keypoints[OCULUS_JOINTS['index']]]),
            middle = np.vstack([raw_keypoints[0], raw_keypoints[OCULUS_JOINTS['middle']]]),
            ring = np.vstack([raw_keypoints[0], raw_keypoints[OCULUS_JOINTS['ring']]]),
            thumb = np.vstack([raw_keypoints[0], raw_keypoints[OCULUS_JOINTS['thumb']]])
        )
    
    # Generate frozen angles for the fingers
    def _generate_frozen_angles(self, joint_angles, finger_type):
        for idx in range(LEAP_JOINTS_PER_FINGER):
            if idx > 0:
                joint_angles[idx + LEAP_JOINT_OFFSETS[finger_type]] = 0.05
            else:
                joint_angles[idx + LEAP_JOINT_OFFSETS[finger_type]] = 0

        return joint_angles

    def _background_logging(self):
        """Background thread for processing log queue"""
        while self._logging_thread_active:
            try:
                # Get data from queue with timeout to allow checking thread_active flag
                log_data = self.log_queue.get(timeout=0.5)
                
                # Log the data
                self.hand_logger.log_frame(
                    finger_input_positions=log_data['finger_input_positions'],
                    finger_computed_angles=log_data['finger_computed_angles'],
                    finger_states=log_data['finger_states']
                )
                
                # Mark task as done
                self.log_queue.task_done()
            except queue.Empty:
                # Queue was empty, just continue
                pass
            except Exception as e:
                print(f"Error in background logging thread: {e}")

    # Apply the retargeted angles to the robot using PyBullet IK
    def _apply_retargeted_angles(self):
        """Apply retargeted angles from hand motion to robot using PyBullet IK"""
        loop_start = time.time()        
        
        # Get finger coordinates
        t1 = time.time()
        hand_keypoints = self._get_finger_coords()
        t2 = time.time()
        
        # Get current joint positions from robot
        desired_joint_angles = self._joint_angle_subscriber.recv_keypoints()
        t3 = time.time()

        # Process all fingers using PyBullet IK
        try:
            # Check if any fingers are frozen or disabled
            active_fingers = {}
            for finger_type in ['thumb', 'index', 'middle', 'ring']:
                if not self.finger_configs[f'freeze_{finger_type}'] and not self.finger_configs[f'no_{finger_type}']:
                    active_fingers[finger_type] = hand_keypoints[finger_type]
            
            # If we have active fingers, solve IK
            if active_fingers:
                # Solve IK for all active fingers at once
                calculated_joint_angles = self.ik_solver.solve_ik(active_fingers)
                
                # Update the desired joint angles with the calculated ones
                # Only update active fingers
                if 'thumb' in active_fingers:
                    desired_joint_angles[12:16] = calculated_joint_angles[12:16]
                if 'index' in active_fingers:
                    desired_joint_angles[0:4] = calculated_joint_angles[0:4]
                if 'middle' in active_fingers:
                    desired_joint_angles[4:8] = calculated_joint_angles[4:8]
                if 'ring' in active_fingers:
                    desired_joint_angles[8:12] = calculated_joint_angles[8:12]
            
            # Handle frozen fingers
            for finger_type in ['thumb', 'index', 'middle', 'ring']:
                if self.finger_configs[f'freeze_{finger_type}'] or self.finger_configs[f'no_{finger_type}']:
                    self._generate_frozen_angles(desired_joint_angles, finger_type)
            
            # Prepare finger data for logging
            finger_data = {}
            for finger_type in ['thumb', 'index', 'middle', 'ring']:
                offset = LEAP_JOINT_OFFSETS[finger_type]
                finger_data[finger_type] = {
                    'input_positions': hand_keypoints[finger_type],
                    'computed_angles': desired_joint_angles[offset:offset + LEAP_JOINTS_PER_FINGER]
                }
                
        except Exception as e:
            print(f"Error in PyBullet IK processing: {e}")
            finger_data = {}
        
        t4 = time.time()
        
        # After processing fingers and before publishing
        if self.logging_enabled and self.hand_logger and finger_data:
            try:
                # Instead of logging directly, add to queue for background processing
                if not self.log_queue.full():  # Skip logging if queue is full rather than blocking
                    log_data = {
                        'finger_input_positions': {k: v['input_positions'].copy() if isinstance(v['input_positions'], np.ndarray) else v['input_positions'] for k, v in finger_data.items()},
                        'finger_computed_angles': {k: v['computed_angles'].copy() if isinstance(v['computed_angles'], np.ndarray) else v['computed_angles'] for k, v in finger_data.items()},
                        'finger_states': desired_joint_angles.copy() if isinstance(desired_joint_angles, np.ndarray) else desired_joint_angles
                    }
                    self.log_queue.put_nowait(log_data)
            except Exception as e:
                print(f"Error queuing log data: {e}")

        # Publish joint angles
        self._joint_angle_publisher.pub_keypoints(
            desired_joint_angles,
            'joint_angles'
        )
        
        t5 = time.time()
        
        # Print timing breakdown every second
        current_time = time.time()
        self._frame_count += 1
        elapsed = current_time - self._start_time
        
        if elapsed >= 1.0 and False:
            fps = self._frame_count / elapsed
            print("\n" + "="*50)
            print(f"FPS: {fps:.2f}")
            print(f"Timing Breakdown:")
            print(f"  Getting keypoints: {(t2-t1)*1000:.1f}ms")
            print(f"  Getting joint pos: {(t3-t2)*1000:.1f}ms")
            print(f"  Processing fingers: {(t4-t3)*1000:.1f}ms")
            print(f"  Robot movement: {(t5-t4)*1000:.1f}ms")
            print(f"  Total loop time: {(t5-loop_start)*1000:.1f}ms")
            
            if hasattr(self, '_last_angles') and self._last_angles is not None:
                if isinstance(desired_joint_angles, dict):
                    desired_angles_array = desired_joint_angles['position']
                else:
                    desired_angles_array = desired_joint_angles
                    
                if isinstance(self._last_angles, dict):
                    last_angles_array = self._last_angles['position']
                else:
                    last_angles_array = self._last_angles
                    
                delta = np.array(desired_angles_array) - np.array(last_angles_array)
                print(f"Change from last command: {delta}")
            print("="*50 + "\n")
            
            self._frame_count = 0
            self._start_time = current_time
        
        self._last_angles = copy(desired_joint_angles)

    def __del__(self):
        # Clean shutdown of logging thread
        if hasattr(self, '_logging_thread_active') and self._logging_thread_active:
            self._logging_thread_active = False
            if self._logging_thread and self._logging_thread.is_alive():
                self._logging_thread.join(timeout=1.0)  # Wait up to 1 second for thread to finish
                
        if hasattr(self, 'thread_pool'):
            self.thread_pool.shutdown()
        if hasattr(self, 'ik_solver'):
            self.ik_solver.close()
        if hasattr(self, 'hand_logger') and self.hand_logger:
            # Try to process any remaining items in the queue
            if hasattr(self, 'log_queue') and self.log_queue:
                try:
                    while not self.log_queue.empty():
                        self.log_queue.get_nowait()
                        self.log_queue.task_done()
                except:
                    pass
            self.hand_logger.close()

def allegro_to_LEAPhand(joints, teleop = True, zeros = True):
    ret_joints = np.array(joints)
    ret_joints[1] -= 0.2
    ret_joints[5] -= 0.2
    ret_joints[9] -= 0.2
    return ret_joints
